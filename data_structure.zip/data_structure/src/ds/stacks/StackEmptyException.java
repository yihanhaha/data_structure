package ds.stacks;

public class StackEmptyException extends RuntimeException {
}
