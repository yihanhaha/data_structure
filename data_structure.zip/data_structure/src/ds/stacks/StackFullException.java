package ds.stacks;

public class StackFullException extends RuntimeException {
}
