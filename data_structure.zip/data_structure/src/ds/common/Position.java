package ds.common;

public interface Position<T> {
    T element();
}
