package ds.queues;

public class QueueEmptyException extends RuntimeException{
}
