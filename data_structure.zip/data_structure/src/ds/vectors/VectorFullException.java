package ds.vectors;

public class VectorFullException extends RuntimeException {
}
