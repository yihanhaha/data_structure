package ds.vectors;

public class RankOutOfBoundsException extends RuntimeException {
}
