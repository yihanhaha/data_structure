package ds.lists;

public class ListEmptyException extends RuntimeException {
}
