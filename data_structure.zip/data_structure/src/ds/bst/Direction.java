package ds.bst;

public enum Direction { LEFT, RIGHT }
